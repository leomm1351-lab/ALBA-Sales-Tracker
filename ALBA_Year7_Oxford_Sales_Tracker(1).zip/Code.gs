const SHEET_NAME = "Sales";

function setup() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty("SPREADSHEET_ID");

  if (!id) {
    const ss = SpreadsheetApp.create("ALBA Year 7 Oxford - Sales Tracker");
    id = ss.getId();
    props.setProperty("SPREADSHEET_ID", id);

    const sheet = ss.getSheets()[0];
    sheet.setName(SHEET_NAME);
    sheet.getRange(1, 1, 1, 8).setValues([[
      "Sale ID", "Date", "Student", "Item", "Quantity", "Unit Price", "Total", "Payment"
    ]]);
    sheet.setFrozenRows(1);
    sheet.getRange("A:H").setHorizontalAlignment("center");
    sheet.getRange("B:B").setNumberFormat("yyyy-mm-dd hh:mm");
    sheet.getRange("F:G").setNumberFormat('#,##0.00');
  }

  Logger.log("Spreadsheet created/connected: " + SpreadsheetApp.openById(id).getUrl());
  return SpreadsheetApp.openById(id).getUrl();
}

function doGet() {
  return HtmlService.createTemplateFromFile("Index")
    .evaluate()
    .setTitle("ALBA Year 7 Oxford — Sales Tracker")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getSheet_() {
  const id = PropertiesService.getScriptProperties().getProperty("SPREADSHEET_ID");
  if (!id) throw new Error("Run setup() once before using the website.");
  return SpreadsheetApp.openById(id).getSheetByName(SHEET_NAME);
}

function addSale(data) {
  if (!data) throw new Error("No sale data received.");

  const student = String(data.student || "").trim();
  const item = String(data.item || "").trim();
  const quantity = Number(data.quantity);
  const unitPrice = Number(data.unitPrice);
  const payment = String(data.payment || "Unpaid");

  if (!student || !item) throw new Error("Student and item are required.");
  if (!Number.isFinite(quantity) || quantity <= 0) throw new Error("Quantity must be greater than 0.");
  if (!Number.isFinite(unitPrice) || unitPrice < 0) throw new Error("Price must be 0 or more.");

  const total = quantity * unitPrice;
  const id = Utilities.getUuid().slice(0, 8).toUpperCase();
  const sheet = getSheet_();

  sheet.appendRow([
    id,
    new Date(),
    student,
    item,
    quantity,
    unitPrice,
    total,
    payment
  ]);

  return { ok: true, id: id, total: total };
}

function getSales() {
  const sheet = getSheet_();
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1) return [];

  return values.slice(1).filter(r => r[0]).map(r => ({
    id: String(r[0]),
    date: r[1] instanceof Date ? r[1].toISOString() : String(r[1]),
    student: String(r[2]),
    item: String(r[3]),
    quantity: Number(r[4]),
    unitPrice: Number(r[5]),
    total: Number(r[6]),
    payment: String(r[7])
  })).reverse();
}
