# ALBA Year 7 Oxford — Class Sales Tracker

A free shared sales-tracking website for the Year 7 Oxford class at ALBA International School.

## What it does
- Shared website that classmates can open with one link
- Add student, item, quantity, price and payment status
- Automatically calculates totals
- Shows total sales, revenue, items sold and number of students
- Search and filter sales
- Stores all records in a Google Sheet
- Uses the supplied ALBA school logo
- Footer says "Created by Leo"

## Setup (free)

1. Open Google Apps Script while signed into the Google account that should own the class sales sheet.
2. Create a new Apps Script project.
3. Replace the default code with the contents of `Code.gs`.
4. Add a new HTML file named `Index` and paste the contents of `Index.html`.
5. In the Apps Script editor, select the `setup` function and click Run once.
   - Google will ask for permission. Approve it.
   - The execution log will show the Google Sheet URL that was created.
6. Click Deploy → New deployment.
7. Choose "Web app".
8. Set "Execute as" to the account that owns the project.
9. For access, choose the option that lets your classmates access it (for example, "Anyone with the link" if your school account allows that).
10. Deploy and copy the web-app URL. Send that one link to the class.

## Important
The website and the Google Sheet are shared. Anyone who can access the web app can add sales. Keep the Google Sheet owner account with a trusted teacher/student.

If your ALBA Google Workspace blocks public web apps, choose the school-only access option available in your account and share the link with the class.

## Optional improvements
- Add product categories
- Add class teams
- Add profit/cost tracking
- Add a leaderboard
- Add charts
- Add a teacher/admin PIN
